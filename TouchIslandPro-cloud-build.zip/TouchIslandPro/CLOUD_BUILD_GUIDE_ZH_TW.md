# Touch Island Pro：手機瀏覽器雲端編譯指南

這個專案附有 GitHub Actions 工作流程，不需要在手機安裝 Android Studio、JDK、Android SDK 或 Gradle。

## 步驟

1. 在 GitHub 建立一個新的空白 repository（例如 `TouchIslandPro`）。
2. 將這個資料夾內的**所有檔案與資料夾**上傳到 repository 根目錄。注意：`.github` 是隱藏名稱，必須一併上傳，且路徑要是 `.github/workflows/build-apk.yml`。
3. 開啟 repository 的 **Actions** 分頁。
4. 選擇 **Build Touch Island Pro APK**。
5. 按 **Run workflow**，再按一次綠色的 **Run workflow** 確認。
6. 等待工作流程完成（綠色勾號）。打開該次執行頁面，滑到 **Artifacts**，下載 `TouchIslandPro-debug-apk`。
7. 解壓縮下載的 artifact，即可取得 `app-debug.apk`，再安裝到 Android 裝置。

## 注意

- 這會產生 debug 測試 APK，不是 Play 商店正式簽署版。
- 雲端編譯成功只代表程式成功打包，不代表已在 Xiaomi 15 Ultra / Xiaomi Pad 7 Pro 上完成觸控校準或實機驗證。
- 初次啟動仍需授予「顯示在其他應用程式上層」權限，並在 KernelSU 中授予 Root。
- 若 GitHub 的 Actions 被停用，請到 repository 的 Settings > Actions 開啟允許執行工作流程。
