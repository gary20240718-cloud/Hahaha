# Touch Island Pro (Alpha source project)

A native Android project for Xiaomi 15 Ultra (HyperOS 3) and Xiaomi Pad 7 Pro. It uses a transparent, non-touchable overlay for cursor drawing and a separate touchable floating control island. The touch reader requests KernelSU root and reads Linux evdev events through `/system/bin/getevent`.

## Current alpha features

- 12 locally drawn cursor styles: Arrow, Dot, Ring, Crosshair, Star, Diamond, Heart, Square, Triangle, Laser, Double Ring, Target.
- Color presets: Blue, White, Red, Green, Purple, Cyan, Yellow, Rainbow.
- Cursor size slider (8–64 dp); default is Blue / Arrow / 24 dp (medium).
- Multiple active touch slots are drawn simultaneously; released slots disappear, with no trail or coordinate text.
- Floating Dynamic Island panel: toggle cursor, cycle style/color, adjust size, hide island while keeping the cursor service running, or stop everything.
- Foreground service is separate from the Activity. Pressing Home or closing the settings Activity does not intentionally stop the service. The notification has actions to show the island or stop the service.
- Runtime screen size and rotation mapping; no Xiaomi-only API is hardcoded.

## Important limitations

This is an **alpha source project, not a tested release APK**. The current execution environment has Java but no Android SDK, Android platform `android.jar`, or Gradle installation, so a signed/compiled APK could not be produced or verified here. Open this folder in Android Studio (AGP 8.7.3 / Kotlin 2.0.21, compile SDK 35) and build the APK there.

Raw touch event access is device/ROM dependent. KernelSU must grant root to Touch Island Pro, and the ROM's SELinux policy must permit the root process to read the touchscreen evdev node. Some Xiaomi builds may deny or alter `getevent` access. The code currently chooses the first input node reporting MT X/Y axes and uses a generic rotation transform; it needs on-device validation and potentially calibration on both devices. Exact zero-offset touch alignment cannot be promised until tested on the actual firmware.

The control island is an application overlay, not a modification of the system status bar. The cursor overlay is marked non-touchable so it should not consume taps. The island itself is touchable only inside its visible panel bounds.

## Build

1. Install Android Studio with Android SDK Platform 35 and a JDK 17 toolchain.
2. Open this `TouchIslandPro` folder.
3. Allow Gradle sync to download Android Gradle Plugin 8.7.3 and Kotlin plugin 2.0.21.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the debug APK on the phone/tablet.

## First run

1. Open Touch Island Pro and grant **Display over other apps**.
2. Tap **Start cursor and Dynamic Island**.
3. Approve the Root request in KernelSU for Touch Island Pro.
4. Allow notifications if prompted.
5. If the status remains at device discovery or reports `getevent` failure, collect the device's `getevent -lp` output and KernelSU root log for compatibility work.
6. On Xiaomi HyperOS, if the service is killed after some time, set the app's battery mode to unrestricted and allow background/autostart where available.

## Runtime behavior

- Home / close the Activity: service should continue while Android keeps the foreground service alive.
- Hide island: only removes the floating control island; cursor monitoring continues. Reopen it from the persistent notification.
- Turn off cursor: stops the root input reader but leaves the island and foreground service available.
- Stop everything: stops reader, removes both overlays, and ends the service.

## Project details

- Application ID: `com.touchisland.pro`
- Min SDK: 26
- Target SDK: 35
- Compile SDK: 35
- No third-party runtime libraries.
