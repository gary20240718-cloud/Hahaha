# No custom shrinking rules in the alpha build.
