package com.touchisland.pro

import android.content.Context
import android.graphics.Color

object SettingsStore {
    private const val PREFS = "touch_island_settings"
    private const val KEY_STYLE = "style"
    private const val KEY_COLOR = "color"
    private const val KEY_SIZE = "size"
    private const val KEY_CURSOR_ENABLED = "cursor_enabled"
    private const val KEY_SERVICE_ACTIVE = "service_active"

    val styles = listOf("Arrow", "Dot", "Ring", "Crosshair", "Star", "Diamond", "Heart", "Square", "Triangle", "Laser", "Double Ring", "Target")
    val colorNames = listOf("Blue", "White", "Red", "Green", "Purple", "Cyan", "Yellow", "Rainbow")
    private val colors = mapOf(
        "Blue" to Color.rgb(38, 126, 255),
        "White" to Color.WHITE,
        "Red" to Color.rgb(255, 65, 75),
        "Green" to Color.rgb(42, 220, 125),
        "Purple" to Color.rgb(175, 100, 255),
        "Cyan" to Color.rgb(0, 220, 235),
        "Yellow" to Color.rgb(255, 210, 55),
        "Rainbow" to Color.MAGENTA
    )

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun style(context: Context) = prefs(context).getString(KEY_STYLE, "Arrow") ?: "Arrow"
    fun colorName(context: Context) = prefs(context).getString(KEY_COLOR, "Blue") ?: "Blue"
    fun color(context: Context): Int = colors[colorName(context)] ?: Color.BLUE
    fun size(context: Context) = prefs(context).getInt(KEY_SIZE, 24).coerceIn(8, 64)
    fun cursorEnabled(context: Context) = prefs(context).getBoolean(KEY_CURSOR_ENABLED, true)
    fun serviceActive(context: Context) = prefs(context).getBoolean(KEY_SERVICE_ACTIVE, false)
    fun setStyle(context: Context, value: String) = prefs(context).edit().putString(KEY_STYLE, value).apply()
    fun setColor(context: Context, value: String) = prefs(context).edit().putString(KEY_COLOR, value).apply()
    fun setSize(context: Context, value: Int) = prefs(context).edit().putInt(KEY_SIZE, value.coerceIn(8, 64)).apply()
    fun setCursorEnabled(context: Context, value: Boolean) = prefs(context).edit().putBoolean(KEY_CURSOR_ENABLED, value).apply()
    fun setServiceActive(context: Context, value: Boolean) = prefs(context).edit().putBoolean(KEY_SERVICE_ACTIVE, value).apply()
}
