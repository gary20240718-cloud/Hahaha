package com.touchisland.pro

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.content.pm.ServiceInfo

class TouchService : Service(), IslandOverlayView.Callbacks {
    private lateinit var windowManager: WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var cursorView: CursorOverlayView? = null
    private var islandView: IslandOverlayView? = null
    private var cursorParams: WindowManager.LayoutParams? = null
    private var islandParams: WindowManager.LayoutParams? = null
    private var reader: RootInputReader? = null
    private var statusMessage = "觸控服務啟動中…"
    private var cursorOn = true

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START
        if (action == ACTION_STOP) {
            stopEverything()
            return START_NOT_STICKY
        }
        ensureForeground()
        when (action) {
            ACTION_TOGGLE_CURSOR -> toggleCursorInternal()
            ACTION_HIDE_ISLAND -> hideIsland()
            ACTION_SHOW_ISLAND -> showIsland()
            ACTION_CYCLE_STYLE -> cycleStyleInternal()
            ACTION_CYCLE_COLOR -> cycleColorInternal()
            ACTION_START -> startRuntime()
            ACTION_UPDATE -> refreshSettings()
        }
        return START_STICKY
    }

    private fun startRuntime() {
        if (!Settings.canDrawOverlays(this)) {
            statusMessage = "請先允許顯示在其他 App 上層"
            stopSelf()
            return
        }
        cursorOn = SettingsStore.cursorEnabled(this)
        SettingsStore.setServiceActive(this, true)
        ensureCursorOverlay()
        showIsland()
        refreshSettings()
        if (cursorOn) startReader()
    }

    private fun ensureForeground() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun ensureCursorOverlay() {
        if (cursorView != null || !Settings.canDrawOverlays(this)) return
        val view = CursorOverlayView(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        try {
            windowManager.addView(view, params)
            cursorView = view
            cursorParams = params
        } catch (t: Throwable) {
            statusMessage = "游標視窗建立失敗：${t.message}"
        }
    }

    private fun showIsland() {
        if (islandView != null || !Settings.canDrawOverlays(this)) return
        val view = IslandOverlayView(this, this)
        val params = WindowManager.LayoutParams(
            dp(190), dp(50),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(8)
        }
        try {
            windowManager.addView(view, params)
            islandView = view
            islandParams = params
            refreshSettings()
        } catch (t: Throwable) {
            statusMessage = "動態島建立失敗：${t.message}"
        }
    }

    private fun startReader() {
        if (reader != null) return
        ensureCursorOverlay()
        statusMessage = "正在啟動 Root 觸控監測…"
        reader = RootInputReader(this, { points ->
            cursorView?.setPoints(points)
        }, { message ->
            mainHandler.post {
                statusMessage = message
                refreshIslandState()
                updateNotification()
            }
        }).also { it.start() }
        refreshIslandState()
    }

    private fun stopReader() {
        reader?.stop()
        reader = null
        cursorView?.setPoints(emptyList())
    }

    private fun refreshSettings() {
        cursorOn = SettingsStore.cursorEnabled(this)
        cursorView?.configure(SettingsStore.style(this), SettingsStore.color(this), SettingsStore.size(this))
        refreshIslandState()
    }

    private fun refreshIslandState() {
        islandView?.updateState(
            cursorOn,
            SettingsStore.style(this),
            SettingsStore.colorName(this),
            SettingsStore.size(this),
            statusMessage
        )
    }

    private fun updateNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification())
    }

    private fun toggleCursorInternal() {
        cursorOn = !cursorOn
        SettingsStore.setCursorEnabled(this, cursorOn)
        if (cursorOn) startReader() else {
            stopReader()
            statusMessage = "游標已關閉；動態島仍在運作"
        }
        refreshSettings()
        updateNotification()
    }

    private fun cycleStyleInternal() {
        val current = SettingsStore.style(this)
        val next = (SettingsStore.styles.indexOf(current).coerceAtLeast(0) + 1) % SettingsStore.styles.size
        SettingsStore.setStyle(this, SettingsStore.styles[next])
        refreshSettings()
    }

    private fun cycleColorInternal() {
        val current = SettingsStore.colorName(this)
        val next = (SettingsStore.colorNames.indexOf(current).coerceAtLeast(0) + 1) % SettingsStore.colorNames.size
        SettingsStore.setColor(this, SettingsStore.colorNames[next])
        refreshSettings()
    }

    override fun toggleCursor() = toggleCursorInternal()
    override fun cycleStyle() = cycleStyleInternal()
    override fun cycleColor() = cycleColorInternal()
    override fun setSize(size: Int) {
        SettingsStore.setSize(this, size)
        refreshSettings()
    }
    override fun hideIsland() {
        islandView?.let { try { windowManager.removeView(it) } catch (_: Throwable) {} }
        islandView = null
        islandParams = null
        statusMessage = "動態島已隱藏；游標服務繼續運作。可從通知列重新開啟。"
        updateNotification()
    }
    override fun stopEverything() {
        SettingsStore.setCursorEnabled(this, true)
        cursorOn = false
        stopReader()
        removeOverlays()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun removeOverlays() {
        cursorView?.let { try { windowManager.removeView(it) } catch (_: Throwable) {} }
        islandView?.let { try { windowManager.removeView(it) } catch (_: Throwable) {} }
        cursorView = null
        islandView = null
        cursorParams = null
        islandParams = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Touch Island Pro", NotificationManager.IMPORTANCE_LOW).apply {
                description = "觸控游標背景服務"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val showIsland = PendingIntent.getService(
            this, 2, Intent(this, TouchService::class.java).setAction(ACTION_SHOW_ISLAND), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 3, Intent(this, TouchService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Touch Island Pro 正在運作")
            .setContentText(if (cursorOn) statusMessage else "游標已關閉，控制島仍可使用")
            .setContentIntent(openIntent)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_view, "顯示控制島", showIsland).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "停止服務", stop).build())
            .build()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density + .5f).toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        SettingsStore.setServiceActive(this, false)
        stopReader()
        removeOverlays()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.touchisland.pro.START"
        const val ACTION_STOP = "com.touchisland.pro.STOP"
        const val ACTION_TOGGLE_CURSOR = "com.touchisland.pro.TOGGLE_CURSOR"
        const val ACTION_HIDE_ISLAND = "com.touchisland.pro.HIDE_ISLAND"
        const val ACTION_SHOW_ISLAND = "com.touchisland.pro.SHOW_ISLAND"
        const val ACTION_CYCLE_STYLE = "com.touchisland.pro.CYCLE_STYLE"
        const val ACTION_CYCLE_COLOR = "com.touchisland.pro.CYCLE_COLOR"
        const val ACTION_UPDATE = "com.touchisland.pro.UPDATE"
        private const val CHANNEL_ID = "touch_island_service"
        private const val NOTIFICATION_ID = 4107
    }
}
