package com.touchisland.pro

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView

class MainActivity : Activity() {
    private val requestOverlay = 501
    private val requestNotifications = 502
    private lateinit var status: TextView
    private lateinit var styleSpinner: Spinner
    private lateinit var colorSpinner: Spinner
    private lateinit var sizeLabel: TextView
    private lateinit var sizeSeek: SeekBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
    }

    private fun buildUi() {
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density + .5f).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(22))
            setBackgroundColor(Color.rgb(9, 11, 16))
        }
        val scroll = ScrollView(this).apply { addView(root) }

        val title = TextView(this).apply {
            text = "TOUCH ISLAND PRO"
            textSize = 23f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        val subtitle = TextView(this).apply {
            text = "Root 多點觸控游標 · Dynamic Island"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(5), 0, dp(18))
        }
        status = TextView(this).apply {
            text = "檢查權限中…"
            textSize = 12f
            setTextColor(Color.rgb(140, 190, 255))
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(24, 31, 43))
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(status)

        root.addView(section("游標樣式"))
        styleSpinner = Spinner(this)
        styleSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, SettingsStore.styles)
        styleSpinner.setSelection(SettingsStore.styles.indexOf(SettingsStore.style(this)).coerceAtLeast(0))
        styleSpinner.setOnItemSelectedListener(SimpleItemSelected { position ->
            SettingsStore.setStyle(this, SettingsStore.styles[position]); sendUpdate()
        })
        root.addView(styleSpinner)

        root.addView(section("游標顏色"))
        colorSpinner = Spinner(this)
        colorSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, SettingsStore.colorNames)
        colorSpinner.setSelection(SettingsStore.colorNames.indexOf(SettingsStore.colorName(this)).coerceAtLeast(0))
        colorSpinner.setOnItemSelectedListener(SimpleItemSelected { position ->
            SettingsStore.setColor(this, SettingsStore.colorNames[position]); sendUpdate()
        })
        root.addView(colorSpinner)

        root.addView(section("游標大小"))
        sizeLabel = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f }
        root.addView(sizeLabel)
        sizeSeek = SeekBar(this).apply {
            max = 56
            progress = SettingsStore.size(this@MainActivity) - 8
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = progress + 8
                    sizeLabel.text = "${value} dp"
                    if (fromUser) SettingsStore.setSize(this@MainActivity, value)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) { sendUpdate() }
            })
        }
        sizeLabel.text = "${SettingsStore.size(this)} dp"
        root.addView(sizeSeek)

        root.addView(section("服務控制"))
        root.addView(actionButton("啟動游標與動態島") { requestAndStart() })
        root.addView(actionButton("只重新顯示動態島") { sendServiceAction(TouchService.ACTION_SHOW_ISLAND) })
        root.addView(actionButton("切換游標開／關（保留控制島）") { sendServiceAction(TouchService.ACTION_TOGGLE_CURSOR) })
        root.addView(actionButton("停止全部服務") { sendServiceAction(TouchService.ACTION_STOP) })

        root.addView(section("目前設計"))
        val notes = TextView(this).apply {
            text = "預設：藍色中型箭頭\n樣式：Arrow、Dot、Ring、Crosshair、Star、Diamond、Heart、Square、Triangle、Laser、Double Ring、Target\n支援多指游標、動態島收合、隱藏控制島後背景持續運作。"
            setTextColor(Color.LTGRAY)
            textSize = 12f
            setLineSpacing(dp(4).toFloat(), 1f)
        }
        root.addView(notes)
        val disclaimer = TextView(this).apply {
            text = "注意：目前為 Alpha 測試工程版。需授予懸浮窗權限及 KernelSU Root。不同 ROM 的 getevent/SELinux 權限與觸控座標方向需要實機校準。"
            setTextColor(Color.rgb(255, 190, 105))
            textSize = 11f
            setPadding(0, dp(18), 0, dp(8))
        }
        root.addView(disclaimer)
        setContentView(scroll)
    }

    private fun section(text: String): TextView {
        val view = TextView(this)
        view.text = text
        view.textSize = 15f
        view.setTextColor(Color.WHITE)
        view.typeface = Typeface.DEFAULT_BOLD
        view.setPadding(0, (18 * resources.displayMetrics.density).toInt(), 0, (7 * resources.displayMetrics.density).toInt())
        return view
    }

    private fun actionButton(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun requestAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), requestOverlay)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), requestNotifications)
            return
        }
        sendServiceAction(TouchService.ACTION_START)
    }

    private fun sendServiceAction(action: String) {
        val active = SettingsStore.serviceActive(this)
        val actualAction = if (!active && (action == TouchService.ACTION_TOGGLE_CURSOR || action == TouchService.ACTION_SHOW_ISLAND)) {
            TouchService.ACTION_START
        } else action
        val intent = Intent(this, TouchService::class.java).setAction(actualAction)
        if (actualAction == TouchService.ACTION_STOP || actualAction == TouchService.ACTION_UPDATE && !active) {
            startService(intent)
        } else if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun sendUpdate() {
        if (Settings.canDrawOverlays(this) && SettingsStore.serviceActive(this)) sendServiceAction(TouchService.ACTION_UPDATE)
    }

    private fun updatePermissionStatus() {
        if (!::status.isInitialized) return
        val overlay = Settings.canDrawOverlays(this)
        val notification = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        status.text = "懸浮窗：${if (overlay) "已允許" else "未允許"}    通知：${if (notification) "已允許" else "未允許"}\nKernelSU：啟動服務時會要求 Root 授權"
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        updatePermissionStatus()
        if (requestCode == requestOverlay && Settings.canDrawOverlays(this)) requestAndStart()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestNotifications) sendServiceAction(TouchService.ACTION_START)
    }

    private class SimpleItemSelected(private val callback: (Int) -> Unit) : android.widget.AdapterView.OnItemSelectedListener {
        private var first = true
        override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (first) { first = false; return }
            callback(position)
        }
        override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
    }
}
