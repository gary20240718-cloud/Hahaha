package com.touchisland.pro

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class CursorOverlayView(context: Context) : View(context) {
    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    @Volatile private var points: List<RootInputReader.TouchPoint> = emptyList()
    private var style = "Arrow"
    private var color = Color.rgb(38, 126, 255)
    private var sizeDp = 24

    fun configure(newStyle: String, newColor: Int, newSize: Int) {
        style = newStyle
        color = newColor
        sizeDp = newSize
        invalidate()
    }

    fun setPoints(newPoints: List<RootInputReader.TouchPoint>) {
        points = newPoints
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val size = sizeDp * density
        points.forEachIndexed { index, point ->
            val c = if (SettingsStore.colorName(context) == "Rainbow") Color.HSVToColor(floatArrayOf((index * 67f) % 360f, 0.9f, 1f)) else color
            drawCursor(canvas, point.x, point.y, size, c)
        }
    }

    private fun drawCursor(canvas: Canvas, x: Float, y: Float, s: Float, c: Int) {
        paint.color = c
        paint.style = Paint.Style.FILL
        paint.strokeWidth = maxStroke(s)
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        paint.clearShadowLayer()
        when (style) {
            "Arrow" -> {
                val p = Path().apply {
                    moveTo(x, y)
                    lineTo(x + s * 0.20f, y + s * 0.76f)
                    lineTo(x + s * 0.37f, y + s * 0.53f)
                    lineTo(x + s * 0.61f, y + s * 0.94f)
                    lineTo(x + s * 0.76f, y + s * 0.85f)
                    lineTo(x + s * 0.51f, y + s * 0.44f)
                    lineTo(x + s * 0.82f, y + s * 0.42f)
                    close()
                }
                paint.setShadowLayer(s * 0.12f, 0f, 0f, c)
                canvas.drawPath(p, paint)
                paint.clearShadowLayer()
                paint.color = Color.WHITE
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = maxStroke(s) * 0.45f
                canvas.drawPath(p, paint)
            }
            "Dot" -> canvas.drawCircle(x, y, s * 0.24f, paint)
            "Ring" -> ring(canvas, x, y, s * 0.34f, c, s * 0.10f)
            "Crosshair" -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = maxStroke(s) * 0.75f
                canvas.drawLine(x - s * .48f, y, x + s * .48f, y, paint)
                canvas.drawLine(x, y - s * .48f, x, y + s * .48f, paint)
                canvas.drawCircle(x, y, s * .18f, paint)
            }
            "Star" -> canvas.drawPath(starPath(x, y, s * .48f, s * .22f, 5), paint)
            "Diamond" -> canvas.drawPath(Path().apply { moveTo(x, y - s*.48f); lineTo(x+s*.34f,y); lineTo(x,y+s*.48f); lineTo(x-s*.34f,y); close() }, paint)
            "Heart" -> {
                val p = Path().apply {
                    moveTo(x, y + s*.38f)
                    cubicTo(x-s*.75f, y-s*.05f, x-s*.43f, y-s*.65f, x, y-s*.25f)
                    cubicTo(x+s*.43f, y-s*.65f, x+s*.75f, y-s*.05f, x, y+s*.38f)
                    close()
                }
                canvas.drawPath(p, paint)
            }
            "Square" -> canvas.drawRoundRect(RectF(x-s*.32f,y-s*.32f,x+s*.32f,y+s*.32f), s*.06f,s*.06f,paint)
            "Triangle" -> canvas.drawPath(Path().apply { moveTo(x,y-s*.46f); lineTo(x+s*.42f,y+s*.34f); lineTo(x-s*.42f,y+s*.34f); close() }, paint)
            "Laser" -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = maxStroke(s) * .85f
                canvas.drawCircle(x, y, s*.28f, paint)
                canvas.drawLine(x-s*.52f,y,x-s*.36f,y,paint)
                canvas.drawLine(x+s*.36f,y,x+s*.52f,y,paint)
            }
            "Double Ring" -> {
                ring(canvas,x,y,s*.38f,c,s*.07f)
                ring(canvas,x,y,s*.19f,c,s*.06f)
            }
            "Target" -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = maxStroke(s)*.65f
                canvas.drawCircle(x,y,s*.40f,paint)
                canvas.drawCircle(x,y,s*.12f,paint)
                canvas.drawLine(x-s*.55f,y,x-s*.34f,y,paint)
                canvas.drawLine(x+s*.34f,y,x+s*.55f,y,paint)
                canvas.drawLine(x,y-s*.55f,x,y-s*.34f,paint)
                canvas.drawLine(x,y+s*.34f,x,y+s*.55f,paint)
            }
        }
    }

    private fun ring(canvas: Canvas, x: Float, y: Float, radius: Float, color: Int, stroke: Float) {
        paint.color = color
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = stroke
        canvas.drawCircle(x,y,radius,paint)
        paint.style = Paint.Style.FILL
    }

    private fun starPath(cx: Float, cy: Float, outer: Float, inner: Float, points: Int): Path {
        val path = Path()
        for (i in 0 until points * 2) {
            val r = if (i % 2 == 0) outer else inner
            val a = -Math.PI / 2.0 + i * Math.PI / points
            val px = cx + (cos(a) * r).toFloat()
            val py = cy + (sin(a) * r).toFloat()
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        path.close()
        return path
    }

    private fun maxStroke(s: Float) = min(s * .11f, 4f * density)
}

class IslandOverlayView(
    context: Context,
    private val callbacks: Callbacks
) : LinearLayout(context) {
    interface Callbacks {
        fun toggleCursor()
        fun cycleStyle()
        fun cycleColor()
        fun setSize(size: Int)
        fun hideIsland()
        fun stopEverything()
    }

    private val density = resources.displayMetrics.density
    private val pill: LinearLayout
    private val panel: LinearLayout
    private val status: TextView
    private val cursorButton: TextView
    private val styleLabel: TextView
    private val colorLabel: TextView
    private val sizeLabel: TextView
    private var expanded = false

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(4), dp(4), dp(4), dp(4))
        setBackgroundColor(Color.TRANSPARENT)

        pill = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(10))
            background = rounded(Color.BLACK, 28)
            elevation = dp(8).toFloat()
        }
        val dot = TextView(context).apply { text = "●"; setTextColor(Color.rgb(38,126,255)); textSize = 13f }
        val title = TextView(context).apply {
            text = "TOUCH ISLAND"
            setTextColor(Color.WHITE)
            textSize = 11f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setPadding(dp(7),0,dp(8),0)
        }
        val chevron = TextView(context).apply { text = "⌄"; setTextColor(Color.LTGRAY); textSize = 17f }
        pill.addView(dot)
        pill.addView(title)
        pill.addView(chevron)
        pill.setOnClickListener { setExpanded(!expanded) }
        addView(pill, LayoutParams(dp(180), dp(42)))

        panel = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(16),dp(14),dp(16),dp(14))
            background = rounded(Color.rgb(15,18,25), 22)
            elevation = dp(12).toFloat()
            visibility = GONE
        }
        val heading = TextView(context).apply {
            text = "TOUCH ISLAND PRO"
            setTextColor(Color.WHITE); textSize = 14f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        status = TextView(context).apply { text = "觸控服務待命"; setTextColor(Color.LTGRAY); textSize = 11f; setPadding(0,dp(4),0,dp(10)) }
        cursorButton = actionText("關閉游標") { callbacks.toggleCursor() }
        styleLabel = actionText("樣式：Arrow  ›") { callbacks.cycleStyle() }
        colorLabel = actionText("顏色：Blue  ›") { callbacks.cycleColor() }
        sizeLabel = TextView(context).apply { text = "大小：24"; setTextColor(Color.WHITE); textSize = 12f; setPadding(0,dp(8),0,dp(3)) }
        val sizeSeek = SeekBar(context).apply {
            max = 56; progress = (SettingsStore.size(context) - 8).coerceIn(0, 56)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = progress + 8
                    sizeLabel.text = "大小：$value"
                    if (fromUser) callbacks.setSize(value)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        val hide = actionText("隱藏動態島（游標繼續）") { callbacks.hideIsland() }
        val stop = actionText("停止全部服務", true) { callbacks.stopEverything() }
        panel.addView(heading)
        panel.addView(status)
        panel.addView(cursorButton)
        panel.addView(styleLabel)
        panel.addView(colorLabel)
        panel.addView(sizeLabel)
        panel.addView(sizeSeek)
        panel.addView(hide)
        panel.addView(stop)
        val panelParams = LayoutParams(dp(300), LayoutParams.WRAP_CONTENT)
        panelParams.topMargin = dp(8)
        addView(panel, panelParams)
    }

    fun setExpanded(value: Boolean) {
        expanded = value
        panel.visibility = if (value) VISIBLE else GONE
        val lp = layoutParams as? WindowManager.LayoutParams
        lp?.let {
            it.width = if (value) dp(320) else dp(190)
            it.height = if (value) LayoutParams.WRAP_CONTENT else dp(50)
            (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).updateViewLayout(this, it)
        }
    }

    fun updateState(cursorOn: Boolean, style: String, color: String, size: Int, message: String) {
        cursorButton.text = if (cursorOn) "關閉游標" else "開啟游標"
        styleLabel.text = "樣式：$style  ›"
        colorLabel.text = "顏色：$color  ›"
        sizeLabel.text = "大小：$size"
        status.text = message
    }

    private fun actionText(textValue: String, danger: Boolean = false, action: () -> Unit): TextView = TextView(context).apply {
        text = textValue
        textSize = 12f
        setTextColor(if (danger) Color.rgb(255,105,110) else Color.WHITE)
        setPadding(dp(10),dp(10),dp(10),dp(10))
        background = rounded(if (danger) Color.rgb(55,24,31) else Color.rgb(31,38,51), 12)
        val params = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        params.topMargin = dp(5)
        layoutParams = params
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }
    private fun dp(v: Int) = (v * density + .5f).toInt()
}
