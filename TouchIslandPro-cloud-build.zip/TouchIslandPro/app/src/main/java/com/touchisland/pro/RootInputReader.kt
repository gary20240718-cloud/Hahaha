package com.touchisland.pro

import android.content.Context
import android.graphics.Point
import android.view.Display
import android.view.WindowManager
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

/** Reads Linux evdev touch events through KernelSU's su command. */
class RootInputReader(
    private val context: Context,
    private val onPoints: (List<TouchPoint>) -> Unit,
    private val onStatus: (String) -> Unit
) {
    data class TouchPoint(val slot: Int, val x: Float, val y: Float)
    private data class Device(val path: String, val minX: Int, val maxX: Int, val minY: Int, val maxY: Int, val multi: Boolean)
    private data class Pointer(var trackingId: Int = -1, var x: Int = 0, var y: Int = 0, var active: Boolean = false)

    private val running = AtomicBoolean(false)
    @Volatile private var process: Process? = null
    @Volatile private var worker: Thread? = null

    fun start() {
        if (!running.compareAndSet(false, true)) return
        worker = Thread({ runReader() }, "TouchIsland-evdev").apply { isDaemon = true; start() }
    }

    fun stop() {
        running.set(false)
        process?.destroy()
        process = null
        worker?.interrupt()
        worker = null
        onPoints(emptyList())
    }

    private fun runReader() {
        try {
            onStatus("正在取得 Root 權限…")
            val idResult = runCommand("id")
            if (!idResult.contains("uid=0")) {
                onStatus("Root 未授權：請在 KernelSU 允許 Touch Island Pro")
                running.set(false)
                return
            }
            onStatus("正在偵測觸控裝置…")
            val listing = runCommand("/system/bin/getevent -lp")
            val device = parseDevices(listing).firstOrNull()
            if (device == null) {
                onStatus("找不到支援的觸控輸入裝置；此 ROM 可能限制 getevent")
                running.set(false)
                return
            }
            onStatus("已連接 ${device.path}，正在追蹤觸控")
            readDevice(device)
        } catch (t: Throwable) {
            if (running.get()) onStatus("觸控讀取失敗：${t.message ?: t.javaClass.simpleName}")
        } finally {
            running.set(false)
            process?.destroy()
            process = null
        }
    }

    private fun runCommand(command: String): String {
        val p = ProcessBuilder("su", "-c", command).redirectErrorStream(true).start()
        process = p
        val result = p.inputStream.bufferedReader().use { it.readText() }
        p.waitFor()
        process = null
        return result
    }

    private fun parseDevices(text: String): List<Device> {
        val blocks = Regex("(?ms)^add device.*?(?=^add device|\\z)").findAll(text).map { it.value }.toList()
        val out = mutableListOf<Device>()
        for (block in blocks) {
            val path = Regex("/dev/input/event\\d+").find(block)?.value ?: continue
            val multi = block.contains("ABS_MT_POSITION_X") && block.contains("ABS_MT_POSITION_Y")
            val xName = if (multi) "ABS_MT_POSITION_X" else "ABS_X"
            val yName = if (multi) "ABS_MT_POSITION_Y" else "ABS_Y"
            if (!block.contains(xName) || !block.contains(yName)) continue
            val x = rangeFor(block, xName) ?: continue
            val y = rangeFor(block, yName) ?: continue
            if (x.second <= x.first || y.second <= y.first) continue
            out += Device(path, x.first, x.second, y.first, y.second, multi)
        }
        return out
    }

    private fun rangeFor(block: String, axis: String): Pair<Int, Int>? {
        val line = block.lineSequence().firstOrNull { it.contains(axis) && it.contains("min") && it.contains("max") } ?: return null
        val match = Regex("min\\s+(-?\\d+),\\s*max\\s+(-?\\d+)").find(line) ?: return null
        return (match.groupValues[1].toIntOrNull() ?: return null) to (match.groupValues[2].toIntOrNull() ?: return null)
    }

    private fun readDevice(device: Device) {
        val command = "/system/bin/getevent -lt ${device.path}"
        val p = ProcessBuilder("su", "-c", command).redirectErrorStream(true).start()
        process = p
        val pointers = mutableMapOf<Int, Pointer>()
        var currentSlot = 0
        val eventPattern = Regex(".*?:\\s+EV_(\\w+)\\s+([A-Z0-9_]+)\\s+([0-9a-fA-F]+)\\s*$")
        BufferedReader(InputStreamReader(p.inputStream)).use { reader ->
            while (running.get()) {
                val line = reader.readLine() ?: break
                val m = eventPattern.matchEntire(line.trim()) ?: continue
                val type = m.groupValues[1]
                val code = m.groupValues[2]
                val value = m.groupValues[3].toLongOrNull(16)?.toInt() ?: continue
                if (type == "ABS") {
                    when (code) {
                        "ABS_MT_SLOT" -> currentSlot = value.coerceIn(0, 31)
                        "ABS_MT_TRACKING_ID" -> {
                            val pointer = pointers.getOrPut(currentSlot) { Pointer() }
                            if (value < 0) pointers.remove(currentSlot)
                            else { pointer.trackingId = value; pointer.active = true }
                        }
                        "ABS_MT_POSITION_X" -> pointers.getOrPut(currentSlot) { Pointer(active = true) }.apply { x = value; active = true }
                        "ABS_MT_POSITION_Y" -> pointers.getOrPut(currentSlot) { Pointer(active = true) }.apply { y = value; active = true }
                        "ABS_X" -> pointers.getOrPut(0) { Pointer(active = true) }.apply { x = value; active = true }
                        "ABS_Y" -> pointers.getOrPut(0) { Pointer(active = true) }.apply { y = value; active = true }
                    }
                } else if (type == "KEY" && code == "BTN_TOUCH" && value == 0) {
                    pointers.clear()
                }
                val points = pointers.filterValues { it.active }.map { (slot, point) ->
                    val mapped = mapToDisplay(point.x, point.y, device)
                    TouchPoint(slot, mapped.first, mapped.second)
                }
                onPoints(points)
            }
        }
        if (running.get() && p.exitValue() != 0) onStatus("getevent 已退出，請檢查 KernelSU 權限或裝置相容性")
    }

    private fun mapToDisplay(rawX: Int, rawY: Int, d: Device): Pair<Float, Float> {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val display: Display = if (android.os.Build.VERSION.SDK_INT >= 30) context.display ?: wm.defaultDisplay else wm.defaultDisplay
        val size = Point()
        @Suppress("DEPRECATION")
        display.getRealSize(size)
        val rotation = display.rotation
        val currentW = max(1, size.x)
        val currentH = max(1, size.y)
        val nx = ((rawX - d.minX).toFloat() / (d.maxX - d.minX).toFloat()).coerceIn(0f, 1f)
        val ny = ((rawY - d.minY).toFloat() / (d.maxY - d.minY).toFloat()).coerceIn(0f, 1f)
        val rotated = when (rotation) {
            SurfaceRotation.ROTATION_90 -> (1f - ny) to nx
            SurfaceRotation.ROTATION_180 -> (1f - nx) to (1f - ny)
            SurfaceRotation.ROTATION_270 -> ny to (1f - nx)
            else -> nx to ny
        }
        // The normalized transform preserves the complete active display area on both portrait and landscape screens.
        return (rotated.first * currentW) to (rotated.second * currentH)
    }

    private object SurfaceRotation {
        const val ROTATION_0 = 0
        const val ROTATION_90 = 1
        const val ROTATION_180 = 2
        const val ROTATION_270 = 3
    }
}
